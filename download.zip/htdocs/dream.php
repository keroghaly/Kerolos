<?php
header('Content-Type: application/json; charset=utf-8');

function reply($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

$apiKey = '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';
/* ====================================================================== */

if (trim($apiKey) === '') {
    reply(['success' => false, 'message' => 'ضع مفتاح OpenRouter في متغير $apiKey داخل الملف'], 500);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    reply(['success' => false, 'message' => 'طريقة الطلب غير صحيحة'], 405);
}

$input = json_decode(file_get_contents('php://input'), true);

if (!is_array($input)) {
    reply(['success' => false, 'message' => 'بيانات الطلب غير صحيحة'], 400);
}

$dream = trim($input['dream'] ?? $input['text'] ?? '');
$focus = trim($input['focus'] ?? 'general');

if ($dream === '') {
    reply(['success' => false, 'message' => 'اكتب الحلم أولاً'], 400);
}

$prompt = "فسر الحلم التالي باللغة العربية. قدم تفسيراً رمزياً محتملاً دون ادعاء معرفة الغيب. قسّم الإجابة إلى تفسير عام والجانب العاطفي والعمل والدراسة والعلاقات. ركز على الجانب التالي: $focus. الحلم: $dream";

$payload = [
    // تم تصحيح اسم النموذج إلى نموذج مجاني مدعوم من OpenRouter
    'model' => 'deepseek/deepseek-r1:free', 
    'messages' => [
        ['role' => 'user', 'content' => $prompt]
    ]
];

$ch = curl_init('https://openrouter.ai/api/v1/chat/completions');
curl_setopt_array($ch, [
    CURLOPT_POST           => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER     => [
        'Authorization: Bearer ' . $apiKey,
        'Content-Type: application/json',
        'HTTP-Referer: http://localhost', // اختيارى: يفضل وضعه لـ OpenRouter
        'X-Title: Dream Interpreter'      // اختيارى: اسم التطبيق
    ],
    CURLOPT_POSTFIELDS     => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_CONNECTTIMEOUT => 15,
    CURLOPT_TIMEOUT        => 60
]);

$result = curl_exec($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);

if ($result === false) {
    $error = curl_error($ch);
    curl_close($ch);
    reply(['success' => false, 'message' => 'تعذر الاتصال بالخدمة', 'details' => $error], 502);
}

curl_close($ch);
$data = json_decode($result, true);

if ($status < 200 || $status >= 300) {
    $hint = '';
    if ($status === 401) {
        $hint = 'المفتاح غير صالح: تأكد أنه API Key صحيح';
    } elseif ($status === 402 || $status === 429) {
        $hint = 'تم تجاوز الحد المجاني أو لا يوجد رصيد، حاول لاحقاً';
    }
    reply([
        'success'     => false,
        'message'     => $hint ?: 'حدث خطأ من OpenRouter',
        'http_status' => $status,
        'details'     => $data['error']['message'] ?? 'خطأ غير معروف'
    ], 502);
}

$answer = $data['choices'][0]['message']['content'] ?? '';

if (is_array($answer)) {
    $answer = implode("\n", array_column($answer, 'text'));
}

if (!is_string($answer) || trim($answer) === '') {
    reply(['success' => false, 'message' => 'لم تصل نتيجة التفسير'], 502);
}

reply([
    'success'        => true,
    'interpretation' => $answer,
    'result'         => $answer
]);
