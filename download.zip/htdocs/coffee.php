<?php
header('Content-Type: application/json; charset=utf-8');

function sendJson($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    sendJson(['success' => false, 'message' => 'طريقة الطلب غير صحيحة'], 405);
}

/* ====== ضع مفتاح Gemini API الحقيقي بين العلامتين ====== */
$apiKey = 'AQ.Ab8RN6IFpbBmDWuAlYquVSTrvqQhgJeBw2WCkgwDN4lleEhdCQ';
/* ======================================================== */

/* الإصلاح: الشرط كان يقارن المفتاح بنفسه فيفشل دائماً */
if (trim($apiKey) === '' || strpos($apiKey, 'PASTE') === 0) {
    sendJson(['success' => false, 'message' => 'يجب إعداد مفتاح Gemini API'], 500);
}

$binary = null;
$declaredMime = null;

/*
 * الإصلاح: الواجهة ترسل FormData بملف اسمه "image" (multipart/form-data)
 * وليس JSON بصيغة data URL. ندعم الاثنين للتوافق.
 */
if (!empty($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
    $binary = file_get_contents($_FILES['image']['tmp_name']);
    $declaredMime = $_FILES['image']['type'] ?: null;
} else {
    $input = json_decode(file_get_contents('php://input'), true);
    $image = is_array($input) ? ($input['image'] ?? '') : '';
    if (is_string($image) &&
        preg_match('/^data:image\/(jpeg|jpg|png|webp);base64,(.+)$/s', $image, $m)) {
        $declaredMime = 'image/' . strtolower($m[1]);
        $binary = base64_decode($m[2], true);
    }
}

if ($binary === false || $binary === null || $binary === '') {
    sendJson(['success' => false, 'message' => 'ارفع صورة واضحة للفنجان بصيغة JPEG أو PNG أو WebP'], 400);
}

if (strlen($binary) > 8 * 1024 * 1024) {
    sendJson(['success' => false, 'message' => 'الصورة كبيرة جدًا (الحد 8 ميجابايت)'], 400);
}

$actualMime = (new finfo(FILEINFO_MIME_TYPE))->buffer($binary);
if (!in_array($actualMime, ['image/jpeg', 'image/png', 'image/webp'], true)) {
    sendJson(['success' => false, 'message' => 'نوع الصورة غير مدعوم'], 400);
}

$inputData = json_decode(file_get_contents('php://input'), true);
$focus = is_array($inputData) ? ($inputData['focus'] ?? 'general') : ($_POST['focus'] ?? 'general');

$prompt = "افحص الصورة أولاً.
إذا لم تكن صورة فنجان قهوة تظهر داخله آثار القهوة، ارفض تفسيرها واطلب صورة فنجان واضحة.
إذا كانت صورة فنجان، قدم قراءة رمزية باللغة العربية، مقسمة إلى:
1. تفسير عام
2. جانب عاطفي
3. العمل والدراسة
4. العلاقات
ركّز بصورة إضافية على الجانب: " . $focus . ".
لا تدّع معرفة الغيب أو التنبؤ المؤكد بالمستقبل.";

$payload = [
    'contents' => [[
        'parts' => [
            ['text' => $prompt],
            [
                'inline_data' => [
                    'mime_type' => $actualMime,
                    'data' => base64_encode($binary)
                ]
            ]
        ]
    ]]
];

$url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';
$ch = curl_init($url);
curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'x-goog-api-key: ' . $apiKey
    ],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE),
    CURLOPT_TIMEOUT => 60
]);
$result = curl_exec($ch);
$curlError = curl_error($ch);
$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($result === false) {
    error_log('Gemini connection error: ' . $curlError);
    sendJson(['success' => false, 'message' => 'تعذر الاتصال بخدمة الذكاء الاصطناعي'], 502);
}

$data = json_decode($result, true);

if ($status < 200 || $status >= 300) {
    error_log('Gemini API error: ' . $result);
    $msg = ($status === 400) ? 'المفتاح غير صالح أو النموذج غير مفعّل' :
        'فشلت قراءة الفنجان. تحقق من المفتاح والنموذج وحدود الاستخدام.';
    sendJson(['success' => false, 'message' => $msg], 502);
}

$answer = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
if ($answer === '') {
    sendJson(['success' => false, 'message' => 'لم تصل قراءة من Gemini'], 502);
}

sendJson([
    'success' => true,
    'interpretation' => $answer,
    'result' => $answer
]);