require("dotenv").config();

const express = require("express");
const multer = require("multer");
const OpenAI = require("openai");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

if (!process.env.OPENAI_API_KEY) {
    console.error("Missing OPENAI_API_KEY in .env");
    process.exit(1);
}

const openai = new OpenAI({
    apiKey: process.env.OPENAI_API_KEY
});

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

const upload = multer({
    storage: multer.memoryStorage(),
    limits: {
        fileSize: 8 * 1024 * 1024
    },
    fileFilter: (req, file, cb) => {
        const allowed = [
            "image/jpeg",
            "image/png",
            "image/webp"
        ];

        if (allowed.includes(file.mimetype)) {
            cb(null, true);
        } else {
            cb(new Error("ارفع صورة JPG أو PNG أو WEBP فقط"));
        }
    }
});

const aspects = {
    "عاطفي": "ركز على المشاعر والعلاقات العاطفية، مع تجنب الجزم بما يشعر به الآخرون.",
    "عام": "قدم قراءة عامة لرموز الحلم ومعانيها المحتملة.",
    "اجتماعي": "ركز على العلاقات الأسرية والاجتماعية والتعامل مع الآخرين.",
    "العمل أو الدراسة": "ركز على الطموحات والعمل والدراسة والتحديات اليومية."
};

app.post("/api/dream", async (req, res) => {
    try {
        const { dream, aspect } = req.body;

        if (typeof dream !== "string" || !dream.trim()) {
            return res.status(400).json({
                error: "اكتب الحلم أولًا."
            });
        }

        if (!aspects[aspect]) {
            return res.status(400).json({
                error: "اختار نوع التفسير من القائمة."
            });
        }

        const response = await openai.responses.create({
            model: process.env.OPENAI_MODEL || "gpt-4.1",
            input: [
                {
                    role: "system",
                    content:
                        "أنت مساعد يتحدث باللغة العربية بأسلوب واضح وهادئ. " +
                        "ساعد المستخدم على التأمل في الرموز المحتملة للأحلام. " +
                        "لا تقدم تفسيرًا على أنه حقيقة مؤكدة أو تنبؤ بالمستقبل. " +
                        "لا تدّعِ معرفة الغيب. وضح أن التفسير احتمالي، " +
                        "واختم بنصيحة عملية لطيفة."
                },
                {
                    role: "user",
                    content:
                        "الحلم:\n" + dream.trim() +
                        "\n\nنوع التفسير المطلوب: " + aspect +
                        "\n\nتركيز التفسير: " + aspects[aspect] +
                        "\n\nاكتب تفسيرًا عربيًا منظمًا ومناسبًا للحلم."
                }
            ]
        });

        res.json({
            result: response.output_text ||
                "لم أتمكن من إعداد التفسير. حاول مرة أخرى."
        });

    } catch (error) {
        console.error("Dream error:", error.message);

        res.status(500).json({
            error: "حصلت مشكلة أثناء تفسير الحلم. حاول مرة أخرى."
        });
    }
});

app.post("/api/coffee", (req, res, next) => {
    upload.single("image")(req, res, (err) => {
        if (err) {
            return res.status(400).json({
                error: err.message || "تعذر استقبال الصورة."
            });
        }

        next();
    });
}, async (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({
                error: "ارفع صورة الفنجان أولًا."
            });
        }

        const mime = req.file.mimetype;

        const base64 = req.file.buffer.toString("base64");

        const imageUrl = `data:${mime};base64,${base64}`;

        const response = await openai.responses.create({
            model: process.env.OPENAI_MODEL || "gpt-4.1",
            input: [
                {
                    role: "system",
                    content:
                        "أنت مساعد يقدم قراءة رمزية ترفيهية لصورة فنجان القهوة. " +
                        "افحص الصورة أولًا. إذا لم تكن الصورة لفنجان قهوة " +
                        "أو لم تظهر تفاصيل الفنجان بوضوح، فلا تقدم قراءة، " +
                        "واطلب من المستخدم صورة واضحة لفنجان القهوة. " +
                        "إذا كانت صورة فنجان، صف العلامات الظاهرة بحذر، " +
                        "ثم قدم قراءة رمزية باللغة العربية دون ادعاء معرفة الغيب " +
                        "أو التنبؤ المؤكد بالمستقبل. اختم بنصيحة لطيفة."
                },
                {
                    role: "user",
                    content: [
                        {
                            type: "input_text",
                            text:
                                "افحص الصورة. إذا كانت لفنجان قهوة، " +
                                "قدم قراءة رمزية لما يظهر فيه. " +
                                "إذا لم تكن كذلك، اطلب صورة فنجان صحيحة."
                        },
                        {
                            type: "input_image",
                            image_url: imageUrl
                        }
                    ]
                }
            ]
        });

        res.json({
            result: response.output_text ||
                "لم أتمكن من قراءة الصورة. جرب صورة أوضح."
        });

    } catch (error) {
        console.error("Coffee error:", error.message);

        res.status(500).json({
            error: "حصلت مشكلة أثناء تحليل الصورة. حاول مرة أخرى."
        });
    }
});

app.get("*path", (req, res, next) => {
    if (req.path.startsWith("/api/")) {
        return res.status(404).json({
            error: "المسار غير موجود."
        });
    }

    res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, () => {
    console.log(`بوابة الأسرار تعمل على http://localhost:${PORT}`);
});